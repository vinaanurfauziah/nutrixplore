const kategoriData = {
    hidangan: {
        nama: 'Hidangan',
        subkategori: [
            { nama: 'Hidangan Pembuka', slug: 'pembuka', icon: 'LuSalad' },
            { nama: 'Sarapan', slug: 'sarapan', icon: 'LuEggFried' },
            { nama: 'Hidangan Utama', slug: 'utama', icon: 'BiBowlRice' },
            {
                nama: 'Hidangan Penutup',
                slug: 'penutup',
                icon: 'GiBerriesBowl',
            },
            { nama: 'Minuman', slug: 'minuman', icon: 'RiDrinksLine' },
            { nama: 'Pelengkap', slug: 'pelengkap', icon: 'TbLeaf' },
            { nama: 'Cemilan', slug: 'cemilan', icon: 'LuGrape' },
            { nama: 'Hidangan Berkuah', slug: 'berkuah', icon: 'LuSoup' },
        ],
    },
    kondisi: {
        nama: 'Kondisi Kesehatan',
        subkategori: [
            { nama: 'Stroke', slug: 'stroke', icon: 'FaBrain' },
            { nama: 'Obesitas', slug: 'obesitas', icon: 'GiFat' },
            { nama: 'Hipertensi', slug: 'hipertensi', icon: 'GiHeartBeats' },
            { nama: 'Paru', slug: 'paru', icon: 'FaLungs' },
            { nama: 'Ginjal', slug: 'ginjal', icon: 'GiKidneys' },
            { nama: 'Kanker', slug: 'kanker', icon: 'GiTumor' },
            { nama: 'Mata', slug: 'mata', icon: 'FaEye' },
            { nama: 'Radang', slug: 'radang', icon: 'GiJoint' },
            { nama: 'Jantung', slug: 'jantung', icon: 'BsFillHeartPulseFill' },
            { nama: 'Otak', slug: 'otak', icon: 'GiBrain' },
            { nama: 'Kulit', slug: 'kulit', icon: 'FaRegFaceFrown' },
            { nama: 'Imunitas', slug: 'imunitas', icon: 'GiAntibody' },
            { nama: 'Mood', slug: 'mood', icon: 'TbMoodCheck' },
            {
                nama: 'Cegah Kanker',
                slug: 'cegah-kanker',
                icon: 'FaRibbon',
            },
            { nama: 'Pencernaan', slug: 'pencernaan', icon: 'GiStomach' },
            { nama: 'Tulang', slug: 'tulang', icon: 'FaBone' },
            { nama: 'Diabetes', slug: 'diabetes', icon: 'GiBlood' },
        ],
    },
    diet: {
        nama: 'Diet',
        subkategori: [
            {
                nama: 'Paleo',
                slug: 'paleo',
                icon: 'FaFish',
            },
            {
                nama: 'Vegan',
                slug: 'vegan',
                icon: 'LuVegan',
            },
            {
                nama: 'Low-Carb',
                slug: 'low-carb',
                icon: 'GiFishEggs',
            },
            {
                nama: 'The Dukan',
                slug: 'the-dukan',
                icon: 'TbMeat',
            },
            {
                nama: 'The Ultra-Low-Fat',
                slug: 'ultra-low-fat',
                icon: 'GiFruitBowl',
            },
            {
                nama: 'Keto',
                slug: 'keto',
                icon: 'PiAvocadoFill',
            },
            {
                nama: 'Mediterrania',
                slug: 'mediterrania',
                icon: 'GiOlive',
            },
            {
                nama: 'Intermittent Fasting',
                slug: 'intermittent-fasting',
                icon: 'TbClock12',
            },
        ],
    },
    alergi: {
        nama: 'Alergi',
        subkategori: [
            { nama: 'Susu', slug: 'susu', icon: 'TbMilkFilled' },
            { nama: 'Telur', slug: 'telur', icon: 'LuEggFried' },
            {
                nama: 'Kacang',
                slug: 'kacang',
                icon: 'GiPeanut',
            },
            {
                nama: 'Ikan',
                slug: 'ikan',
                icon: 'FaFish',
            },
            {
                nama: 'Kerang',
                slug: 'kerang',
                icon: 'GiNautilusShell',
            },
            {
                nama: 'Daging Ayam',
                slug: 'daging-ayam',
                icon: 'GiChickenOven',
            },
            {
                nama: 'Kuning Telur',
                slug: 'kuning-telur',
                icon: 'FaEgg',
            },
            {
                nama: 'Gandum',
                slug: 'gandum',
                icon: 'GiWheat',
            },
        ],
    },
    nutrisi: {
        nama: 'Nutrisi',
        subkategori: [
            {
                nama: 'Tinggi Protein',
                slug: 'tinggi_protein',
                icon: 'LuEggFried',
            },
            {
                nama: 'Tinggi Serat',
                slug: 'tinggi_serat',
                icon: 'GiHerbsBundle',
            },
            {
                nama: 'Rendah Natrium',
                slug: 'rendah_natrium',
                icon: 'GiSaltShaker',
            },
            {
                nama: 'Rendah Karbohidrat',
                slug: 'rendah_karbohidrat',
                icon: 'BiBowlRice',
            },
            { nama: 'Rendah Gula', slug: 'rendah_gula', icon: 'LuCandy' },
            {
                nama: 'Tinggi Kalsium',
                slug: 'tinggi_kalsium',
                icon: 'FaBone',
            },
            {
                nama: 'Rendah Lemak',
                slug: 'rendah_lemak',
                icon: 'GiChickenLeg',
            },
            { nama: 'Tanpa Kacang', slug: 'tanpa_kacang', icon: 'GiPeanut' },
        ],
    },
    metode: {
        nama: 'Metode Memasak',
        subkategori: [
            { nama: 'Rebus', slug: 'rebus', icon: 'PiCookingPotFill' },
            { nama: 'Goreng', slug: 'goreng', icon: 'TbCooker' },
            { nama: 'Kukus', slug: 'kukus', icon: 'CgSmartHomeCooker' },
            { nama: 'Panggang', slug: 'panggang', icon: 'TbGrill' },
            { nama: 'Tumis', slug: 'tumis', icon: 'CgSmartHomeCooker' },
            {
                nama: 'Merebus Perlahan',
                slug: 'merebus_perlahan',
                icon: 'LuCookingPot',
            },
            {
                nama: 'Menggulai (Stewing)',
                slug: 'menggulai',
                icon: 'GiPressureCooker',
            },
            {
                nama: 'Menggoreng Cepat (Stir Frying)',
                slug: 'menggoreng_cepat',
                icon: 'TbCooker',
            },
        ],
    },
};

export default kategoriData;
