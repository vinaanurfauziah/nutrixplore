const articles = [
    {
        category: 'KATEGORI',
        title: 'Lorem Ipsum Dolor Sit Amet',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        imageUrl:
            'https://flowbite.s3.amazonaws.com/blocks/marketing-ui/content/office-long-2.png',
        link: '/article/detailArticle',
    },
    {
        category: 'KATEGORI',
        title: 'Judul Artikel 2',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        imageUrl:
            'https://flowbite.s3.amazonaws.com/blocks/marketing-ui/content/office-long-2.png',
        link: '#',
    },
    {
        category: 'KATEGORI',
        title: 'Judul Artikel 3',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        imageUrl:
            'https://flowbite.s3.amazonaws.com/blocks/marketing-ui/content/office-long-2.png',
        link: '#',
    },
    {
        category: 'KATEGORI',
        title: 'Judul Artikel 4',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        imageUrl:
            'https://flowbite.s3.amazonaws.com/blocks/marketing-ui/content/office-long-2.png',
        link: '#',
    },
];

export default articles;
