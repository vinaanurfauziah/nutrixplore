export default function ArticleFilter({ options, selected = [], onChange }) {
    const toggleOption = (option) => {
        let updated = [];

        // Jika user klik "Semua Artikel"
        if (option === 'Semua Artikel') {
            updated = ['Semua Artikel'];
        } else {
            // Hapus "Semua Artikel" jika memilih kategori lain
            updated = selected.filter((item) => item !== 'Semua Artikel');

            // Toggle logika biasa
            if (selected.includes(option)) {
                updated = updated.filter((item) => item !== option);
            } else {
                updated = [...updated, option];
            }
        }

        onChange(updated);
    };

    return (
        <div className="mb-4 flex flex-wrap gap-2">
            {options.map((option, index) => {
                const isActive = selected.includes(option);

                return (
                    <button
                        key={index}
                        onClick={() => toggleOption(option)}
                        className={`transform rounded-full border px-4 py-2 text-sm font-medium transition-all duration-300 ease-in-out ${
                            isActive
                                ? 'bg-[#70B9BE] text-white'
                                : 'bg-white text-gray-800 hover:bg-gray-100'
                        } hover:scale-105 hover:shadow-md`}
                    >
                        {option}
                    </button>
                );
            })}
        </div>
    );
}
